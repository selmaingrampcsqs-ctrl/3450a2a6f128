// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Enforce call deadline\n", stdout);
  return lionss_run_workload("grpc_deadline");
}
