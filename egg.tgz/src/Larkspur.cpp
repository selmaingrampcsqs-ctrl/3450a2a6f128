// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Render larkspur bloom\n", stdout);
  return lionss_run_workload("Larkspur");
}
