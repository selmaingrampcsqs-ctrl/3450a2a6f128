// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Step backward\n", stdout);
  return lionss_run_workload("timeTravelDebug");
}
